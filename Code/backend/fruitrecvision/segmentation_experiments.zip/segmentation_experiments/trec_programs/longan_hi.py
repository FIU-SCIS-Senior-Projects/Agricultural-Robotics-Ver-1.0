import cv2
import numpy as np

img = cv2.imread('../trec_images/longan_hi/longan_hi.jpg')

kernel = np.ones((3,3),np.uint8)

img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
high_hue_indices = img[:,:,0] > 20
img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
img[high_hue_indices] = 0

img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.bilateralFilter(img,3,50,50)
img = cv2.GaussianBlur(img,(3,3),0)
img = cv2.dilate(img,kernel,iterations = 1)

cv2.imwrite('../trec_images/longan_hi/longan_hi_high_hue_subtraction.jpg',img)

# red_less_than_green_indices = img[:,:,2] <= img[:,:,1]
# img[red_less_than_green_indices] = 0
# 
# red_less_than_blue_indices = img[:,:,2] <= img[:,:,0]
# img[red_less_than_blue_indices] = 0

# green_less_than_blue_indices = img[:,:,1] <= img[:,:,0]
# img[green_less_than_blue_indices] = 0

# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.GaussianBlur(img,(3,3),0)
# img = cv2.dilate(img,kernel,iterations = 1)

# cv2.imwrite('../trec_images/longan_hi/longan_hi_not_brown_subtraction.jpg',img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
low_sat_indices = img[:,:,1] < 30
img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
img[low_sat_indices] = 0

img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.bilateralFilter(img,3,50,50)
# img = cv2.GaussianBlur(img,(3,3),0)
img = cv2.dilate(img,kernel,iterations = 1)

cv2.imwrite('../trec_images/longan_hi/longan_hi_low_sat_subtraction.jpg',img)

# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)
# img = cv2.GaussianBlur(img,(3,3),0)
# img = cv2.bilateralFilter(img,5,50,50)

img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
low_val_indices = img[:,:,2] < 50
img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
img[low_val_indices] = 0

img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.GaussianBlur(img,(3,3),0)
# img = cv2.bilateralFilter(img,3,50,50)
img = cv2.dilate(img,kernel,iterations = 1)

cv2.imwrite('../trec_images/longan_hi/longan_hi_low_val_subtraction.jpg',img)

# img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
# high_hue_indices = img[:,:,0] > 50
# img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
# img[high_hue_indices] = 0

# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.GaussianBlur(img,(3,3),0)
# img = cv2.dilate(img,kernel,iterations = 1)

# cv2.imwrite('../trec_images/longan_hi/longan_hi_high_hue_subtraction.jpg',img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
ret, img = cv2.threshold(img,25,255,0)
cv2.imwrite('../trec_images/longan_hi/longan_hi_threshold.jpg',img)
img_cntr, contours, hierarchy = cv2.findContours(img,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
print (len(contours))
img = cv2.drawContours(img_cntr, contours, -1, (255,255,0), 3)
cv2.imwrite('../trec_images/longan_hi/longan_hi_contour.jpg',img)
