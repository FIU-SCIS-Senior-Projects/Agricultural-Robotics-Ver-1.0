import cv2
import numpy as np

img = cv2.imread('../trec_images/avocado_1280x720.jpg')
img = cv2.Laplacian(img,cv2.CV_32F)
cv2.imwrite('../trec_images/avocado_1280x720_laplacian.jpg',img)