import cv2
import numpy as np

img = cv2.imread('../trec_images/sapoti_1_720x477.jpg')

# img = cv2.bilateralFilter(img,3,50,50)
# img = cv2.bilateralFilter(img,3,50,50)
# img = cv2.bilateralFilter(img,3,50,50)
# img = cv2.bilateralFilter(img,3,50,50)
# img = cv2.bilateralFilter(img,3,50,50)

# cv2.imwrite('../trec_images/sapoti_1_bilateral_01.jpg',img)

red_less_than_green_indices = img[:,:,2] <= img[:,:,1]
# print (len(red_less_than_green_indices))
# print (len(red_less_than_green_indices[0]))
img[red_less_than_green_indices] = 0

cv2.imwrite('../trec_images/sapoti_1_red_less_than_green_subtraction.jpg',img)

green_less_than_blue_indices = img[:,:,1] <= img[:,:,0]
img[green_less_than_blue_indices] = 0

cv2.imwrite('../trec_images/sapoti_1_not_brown_subtraction.jpg',img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
low_sat_indices = img[:,:,1] < 30

img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
img[low_sat_indices] = 0
# print ("low_sat_indices")
# print (len(low_sat_indices))
# print (len(low_sat_indices[0]))
# print (low_sat_indices)

cv2.imwrite('../trec_images/sapoti_1_low_sat_subtraction.jpg',img)

# img_red = img[:,:,2]
# img_green = img[:,:,1]
# print ("img_green")
# print (len(img_green))
# print (len(img_green[0]))
# print (img_green)

# green_equals_zero_indices = img_green == 0
# print ("green_equals_zero_indices")
# print (len(green_equals_zero_indices))
# print (len(green_equals_zero_indices[0]))
# print (green_equals_zero_indices)

# img_green[green_equals_zero_indices] = 1

# img_red = img_red.astype(float)
# img_green = img_green.astype(float)

# print ("img_green")
# print (len(img_green))
# print (len(img_green[0]))
# print (img_green)

# low_red_green_ratio_indices = img_red / img_green < 1.05
# print ("low_red_green_ratio_indices")
# print (len(low_red_green_ratio_indices))
# print (len(low_red_green_ratio_indices[0]))
# print (low_red_green_ratio_indices)

# img[low_red_green_ratio_indices] = 0

# cv2.imwrite('../trec_images/sapoti_1_low_red_green_ratio_subtraction.jpg',img)

# img = np.ceil(img * 1.25)
# img = img.astype(np.uint8)

# print("img")
# print(img)
kernel = np.ones((3,3),np.uint8)
# img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

img = cv2.erode(img,kernel,iterations = 1)

# img = cv2.GaussianBlur(img,(3,3),0)
# cv2.imwrite('../trec_images/sapoti_1_gaussian_01.jpg',img)

# img = cv2.bilateralFilter(img,7,35,35)
# cv2.imwrite('../trec_images/sapoti_1_bilateral_01.jpg',img)

img = cv2.dilate(img,kernel,iterations = 1)

# img = cv2.bilateralFilter(img,7,35,35)
# cv2.imwrite('../trec_images/sapoti_1_bilateral_01.jpg',img)

# img = cv2.dilate(img,kernel,iterations = 3)
# img = cv2.erode(img,kernel,iterations = 3)

cv2.imwrite('../trec_images/sapoti_1_open_morph.jpg',img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

cv2.imwrite('../trec_images/sapoti_1_open_morph_gray.jpg',img)

img = cv2.GaussianBlur(img,(3,3),0)
cv2.imwrite('../trec_images/sapoti_1_gaussian_01.jpg',img)

ret, img = cv2.threshold(img,0,255,0)

img = cv2.erode(img,kernel,iterations = 3)
img = cv2.dilate(img,kernel,iterations = 1)

img = cv2.erode(img,kernel,iterations = 3)
img = cv2.dilate(img,kernel,iterations = 1)

img = cv2.GaussianBlur(img,(3,3),0)
ret, img = cv2.threshold(img,0,255,0)

img = cv2.GaussianBlur(img,(3,3),0)
ret, img = cv2.threshold(img,0,255,0)
img = cv2.erode(img,kernel,iterations = 1)

# img = cv2.erode(img,kernel,iterations = 3)
# img = cv2.dilate(img,kernel,iterations = 3)

img = cv2.GaussianBlur(img,(3,3),0)
ret, img = cv2.threshold(img,0,255,0)

img = cv2.GaussianBlur(img,(3,3),0)
ret, img = cv2.threshold(img,50,255,0)
img = cv2.erode(img,kernel,iterations = 1)

img = cv2.GaussianBlur(img,(3,3),0)
ret, img = cv2.threshold(img,50,255,0)

img = cv2.GaussianBlur(img,(3,3),0)
ret, img = cv2.threshold(img,50,255,0)
img = cv2.erode(img,kernel,iterations = 1)

# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)

# img = cv2.GaussianBlur(img,(9,9),0)
cv2.imwrite('../trec_images/sapoti_1_gaussian_02.jpg',img)

# img = cv2.erode(img,kernel,iterations = 5)
# img = cv2.dilate(img,kernel,iterations = 5)
cv2.imwrite('../trec_images/sapoti_1_open_morph_thresh.jpg',img)

# ret, img = cv2.threshold(img,50,255,0)
img_cntr, contours, hierarchy = cv2.findContours(img,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
img = cv2.drawContours(img_cntr, contours, -1, (255,255,0), 3)
cv2.imwrite('../trec_images/sapoti_1_contour.jpg',img)

# print(len(contours))

# img_red = img[:,:,2]
# img_green = img[:,:,1]
# print ("img_green")
# print (len(img_green))
# print (len(img_green[0]))
# print (img_green)

# green_not_zero_indices = img_green > 0
# print ("green_not_zero_indices")
# print (len(green_not_zero_indices))
# print (len(green_not_zero_indices[0]))
# print (green_not_zero_indices)

# img_red = img_red.astype(float)
# img_green = img_green.astype(float)
# print ("img_green")
# print (len(img_green))
# print (len(img_green[0]))
# print (img_green)

# img_green = np.reciprocal(img_green)
# print ("reciprocal_img_green")
# print (len(img_green))
# print (len(img_green[0]))
# print (img_green)

# green_approaching_infinity_indices = img_green > 255.0
# print ("green_approaching_infinity_indices")
# print (len(green_approaching_infinity_indices))
# print (green_approaching_infinity_indices)

# img_green[green_approaching_infinity_indices] = 1
# print ("img_green_less_than_infinity")
# print (len(img_green))
# print (len(img_green[0]))
# print (img_green)

# low_red_green_ratio_indices = img_red * img_green < 1.0
# print ("low_red_green_ratio_indices")
# print (len(low_red_green_ratio_indices))
# print (len(low_red_green_ratio_indices[0]))
# print (low_red_green_ratio_indices)

# print ("low_red_green_ratio_indices")
# print (low_red_green_ratio_indices)

# img[low_red_green_ratio_indices] = 0

# cv2.imwrite('../trec_images/sapoti_1_low_red_green_ratio_subtraction.jpg',img)


















####################################################
####################################################

# kernel = np.ones((3,3),np.uint8)
# img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

# cv2.imwrite('../trec_images/sapoti_1_open_morph.jpg',img)

###########################################################
###########################################################

# img = cv2.imread('tree_carambola_736x552.jpg')

# img = cv2.bilateralFilter(img,25,35,35)
# img = cv2.bilateralFilter(img,23,35,35)
# img = cv2.bilateralFilter(img,21,35,35)
# img = cv2.bilateralFilter(img,19,35,35)
# img = cv2.bilateralFilter(img,17,35,35)
# img = cv2.bilateralFilter(img,15,35,35)
# img = cv2.bilateralFilter(img,13,35,35)
# img = cv2.bilateralFilter(img,11,35,35)
# img = cv2.bilateralFilter(img,9,35,35)
# img = cv2.bilateralFilter(img,7,35,35)
# img = cv2.bilateralFilter(img,5,35,35)
# img = cv2.bilateralFilter(img,3,35,35)

# cv2.imwrite('tree_carambola_736x552_rbg_bilat_1.jpg',img)

# green_major_indices = img[:,:,2] < img[:,:,1]
# img[green_major_indices] = 0

# cv2.imwrite('tree_carambola_736x552_rbg_green_sub_1.jpg',img)

# blue_major_indices = (img[:,:,2] - img[:,:,0]) / (img[:,:,2] + img[:,:,0]) < 0.5
# img[blue_major_indices] = 0

# cv2.imwrite('tree_carambola_736x552_rbg_blue_sub_1.jpg',img)

# img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
# low_sat_indices = img[:,:,1] < 70
# img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
# img[low_sat_indices] = 0

# cv2.imwrite('tree_carambola_736x552_hsv_low_sat_sub_1.jpg',img)

# kernel = np.ones((3,3),np.uint8)

# img = cv2.dilate(img,kernel,iterations = 2)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 2)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 2)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 2)
# img = cv2.erode(img,kernel,iterations = 1)

# cv2.imwrite('tree_carambola_736x552_rgb_dilate-erode_1.jpg',img)