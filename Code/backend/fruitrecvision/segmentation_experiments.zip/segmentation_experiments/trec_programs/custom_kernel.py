import cv2
import numpy as np

#src img arr has the form (y, x) because it's grayscale (1 ch)
def convolve(src,knl_sz,lwr_bnd):
	src_shp = np.shape(src)
	dst = np.zeros(src_shp)
	pdng = knl_sz / 2
	for y in range(pdng,src_shp[0] - pdng):
		for x in range(pdng,src_shp[1] - pdng):
			anchor = src[y,x]
			ancr_bnd = anchor - lwr_bnd
			dst_val = 0
			for n in range(pdng):
				m = (n+1)
				left = src[y,x-m]
				up = src[y+m,x]
				right = src[y,x+m]
				down = src[y-m,x]
				set_val = False
				if left < anchor and left > ancr_bnd:
					if up < anchor and up > ancr_bnd or down < anchor and down > ancr_bnd:
						set_val = True
				elif right < anchor and right > ancr_bnd:
					if up < anchor and up > ancr_bnd or down < anchor and down > ancr_bnd:
						set_val = True			
				if set_val:
					dst_val += 1
			if dst_val == pdng:
				dst[y,x] = 255
	return dst
	
#recall that an image is no more than an ndarray
img = cv2.imread('../trec_images/coconut_2/coconut_2_720x477.jpg')

img = cv2.bilateralFilter(img,3,25,25)
img = cv2.bilateralFilter(img,3,25,25)
img = cv2.bilateralFilter(img,3,25,25)
img = cv2.bilateralFilter(img,3,25,25)
img = cv2.bilateralFilter(img,3,25,25)
cv2.imwrite('../trec_images/coconut_2/coconut_2_custom_kernel_bilateral.jpg',img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

img = convolve(img,5,50)

# kernel = np.ones((3,3),np.uint8)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)
# img = cv2.erode(img,kernel,iterations = 3)
# img = cv2.dilate(img,kernel,iterations = 2)

cv2.imwrite('../trec_images/coconut_2/coconut_2_custom_kernel.jpg',img)
print(type(img))
print(np.shape(img))
#so, we need a function that operates on a ndarray
#we will iterate over the x,y 2D plane and compare the ch values