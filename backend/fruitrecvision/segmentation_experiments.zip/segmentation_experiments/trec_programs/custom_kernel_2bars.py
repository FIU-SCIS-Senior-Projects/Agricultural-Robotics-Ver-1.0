import cv2
import numpy as np

#src img arr has the form (y, x) because it's grayscale (1 ch)
def convolve(src,knl_sz,lwr_bnd):
	src_shp = np.shape(src)
	dst = np.zeros(src_shp)
	pdng = knl_sz / 2
	for y in range(pdng,src_shp[0] - pdng):
		for x in range(pdng,src_shp[1] - pdng):
			anchor = src[y,x]
			ancr_bnd = anchor - lwr_bnd
			dst_val = 0
			
			for n in range(pdng):

				m = (n+1)

				inner_left = src[y,x-n]
				inner_up = src[y+n,x]
				inner_right = src[y,x+n]
				inner_down = src[y-n,x]

				outer_left = src[y,x-m]
				outer_up = src[y+m,x]
				outer_right = src[y,x+m]
				outer_down = src[y-m,x]

				inner_lower_left = src[y-n,x-n]
				inner_upper_left = src[y+n,x-n]
				inner_lower_right = src[y-n,x+n]
				inner_upper_right = src[y+n,x+n]

				outer_lower_left = src[y-m,x-m]
				outer_upper_left = src[y+m,x-m]
				outer_lower_right = src[y-m,x+m]
				outer_upper_right = src[y+m,x+m]

				set_val = False
				
				if outer_left < inner_left:
					if outer_up < inner_up and outer_upper_left < inner_upper_left or outer_down < inner_down and outer_lower_left < inner_lower_left:
						set_val = True
				elif outer_right < inner_right:
					if outer_up < inner_up and outer_upper_right < inner_upper_right or outer_down < inner_down and outer_lower_right < inner_lower_right:
						set_val = True			
				
				if set_val:
					dst_val += 1
			
			if dst_val == pdng:
				dst[y,x] = 255
	
	return dst
	
#recall that an image is no more than an ndarray
img = cv2.imread('../trec_images/coconut_2/coconut_2_720x477.jpg')

# img = cv2.bilateralFilter(img,5,50,50)

kernel = np.ones((3,3),np.uint8)

red_less_than_blue_indices = img[:,:,2] <= img[:,:,0]
img[red_less_than_blue_indices] = 0

# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)

# img = cv2.bilateralFilter(img,3,25,25)
# img = cv2.bilateralFilter(img,3,35,35)
# img = cv2.bilateralFilter(img,3,45,45)

green_less_than_blue_indices = img[:,:,1] <= img[:,:,0]
img[green_less_than_blue_indices] = 0

# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)

# img = cv2.bilateralFilter(img,3,25,25)
# img = cv2.bilateralFilter(img,3,35,35)
# img = cv2.bilateralFilter(img,3,45,45)

blue_close_to_average_indices = np.abs((img[:,:,2] + img[:,:,1] + img[:,:,0]) / 3 - img[:,:,0]) < 25
img[blue_close_to_average_indices] = 0

# img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.bilateralFilter(img,3,45,45)
# img = cv2.dilate(img,kernel,iterations = 1)

# img = cv2.bilateralFilter(img,3,25,25)
# img = cv2.bilateralFilter(img,3,35,35)
# img = cv2.bilateralFilter(img,3,45,45)

# img = cv2.erode(img,kernel,iterations = 2)
# img = cv2.dilate(img,kernel,iterations = 2)

cv2.imwrite('../trec_images/coconut_2/coconut_2_custom_kernel_bilateral.jpg',img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

# img = cv2.dilate(img,kernel,iterations = 1)
# # img = cv2.bilateralFilter(img,5,5,50)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)
# img = cv2.erode(img,kernel,iterations = 1)

img = convolve(img,5,50)

# img = cv2.erode(img,kernel,iterations = 3)
# img = cv2.dilate(img,kernel,iterations = 2)

cv2.imwrite('../trec_images/coconut_2/coconut_2_custom_kernel.jpg',img)
print(type(img))
print(np.shape(img))
#so, we need a function that operates on a ndarray
#we will iterate over the x,y 2D plane and compare the ch values