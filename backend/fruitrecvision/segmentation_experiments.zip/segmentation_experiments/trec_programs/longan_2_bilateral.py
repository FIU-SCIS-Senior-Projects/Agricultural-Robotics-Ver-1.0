import cv2
import numpy as np

img = cv2.imread('../trec_images/longan_2/longan_2_720x477.jpg')

# img = cv2.bilateralFilter(img,3,50,50)
# img = cv2.bilateralFilter(img,3,50,50)
# img = cv2.bilateralFilter(img,3,50,50)
# img = cv2.bilateralFilter(img,3,50,50)
# img = cv2.bilateralFilter(img,3,50,50)

# cv2.imwrite('../trec_images/longan_2/longan_2_bilateral_01.jpg',img)

red_less_than_green_indices = img[:,:,2] <= img[:,:,1]
print (len(red_less_than_green_indices))
print (len(red_less_than_green_indices[0]))
img[red_less_than_green_indices] = 0

green_less_than_blue_indices = img[:,:,1] <= img[:,:,0]
img[green_less_than_blue_indices] = 0

cv2.imwrite('../trec_images/longan_2/longan_2_not_brown_subtraction.jpg',img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
low_sat_indices = img[:,:,1] < 30

img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
img[low_sat_indices] = 0
print ("low_sat_indices")
print (len(low_sat_indices))
print (len(low_sat_indices[0]))
print (low_sat_indices)

cv2.imwrite('../trec_images/longan_2/longan_2_low_sat_subtraction.jpg',img)

# kernel = np.ones((3,3),np.uint8)
# img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

# img = cv2.erode(img,kernel,iterations = 1)

# img = cv2.GaussianBlur(img,(3,3),0)
# cv2.imwrite('../trec_images/longan_2/longan_2_gaussian_01.jpg',img)

# img = cv2.bilateralFilter(img,7,35,35)
# cv2.imwrite('../trec_images/longan_2/longan_2_bilateral_01.jpg',img)

# img = cv2.dilate(img,kernel,iterations = 1)

# img = cv2.bilateralFilter(img,7,35,35)
# cv2.imwrite('../trec_images/longan_2/longan_2_bilateral_01.jpg',img)

# img = cv2.dilate(img,kernel,iterations = 3)
# img = cv2.erode(img,kernel,iterations = 3)

# cv2.imwrite('../trec_images/longan_2/longan_2_open_morph.jpg',img)

# img_gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

# cv2.imwrite('../trec_images/longan_2/longan_2_gray.jpg',img_gray)
###########################################
# img_gray = 255 - img_gray

# cv2.imwrite('../trec_images/longan_2/longan_2_gray_inverted.jpg',img_gray)

# # img_gray = cv2.bilateralFilter(img_gray,3,5,35)
# # cv2.imwrite('../trec_images/longan_2/longan_2_bilateral_gray_01.jpg',img_gray)

# # img_gray = cv2.GaussianBlur(img_gray,(3,3),0)
# # cv2.imwrite('../trec_images/longan_2/longan_2_gray_gaussian_01.jpg',img_gray)

# circles = cv2.HoughCircles(img_gray, cv2.HOUGH_GRADIENT,1,20,param1=50,param2=30,minRadius=0,maxRadius=30)
# print(len(circles[0]))
# # ret, img = cv2.threshold(img,0,255,0)
# # cv2.imwrite('../trec_images/longan_2/longan_2_thresh.jpg',img)

# for i in circles[0,:]:
#     # draw the outer circle
#     cv2.circle(img,(i[0],i[1]),i[2],(0,255,0),2)
#     # draw the center of the circle
#     cv2.circle(img,(i[0],i[1]),2,(0,0,255),3)

# # img_gray = cv2.circle(img_gray, circles, -1, (255,255,0), 3)
# cv2.imwrite('../trec_images/longan_2/longan_2_circles.jpg',img)

#######

kernel = np.ones((3,3),np.uint8)
# img = cv2.dilate(img,kernel,iterations = 1)
# cv2.imwrite('../trec_images/longan_2/longan_2_eroded.jpg',img)

img_dilate = cv2.dilate(img,kernel,iterations=1)
img_erode = cv2.erode(img,kernel,iterations=1)

img_gradient = img_dilate - img_erode
cv2.imwrite('../trec_images/longan_2/longan_2_gradient.jpg',img_gradient)

# img_gradient = cv2.bilateralFilter(img_gradient,7,35,35)
# cv2.imwrite('../trec_images/longan_2/longan_2_bilateral_01.jpg',img_gradient)

img_gray = cv2.cvtColor(img_gradient,cv2.COLOR_BGR2GRAY)
cv2.imwrite('../trec_images/longan_2/longan_2_gray.jpg',img_gray)

ret, img_thresh_high = cv2.threshold(img_gray,100,255,0)
cv2.imwrite('../trec_images/longan_2/longan_2_thresh_high.jpg',img_thresh_high)

img_thresh_high = cv2.dilate(img_thresh_high,kernel,iterations=1)
img_thresh_high = cv2.erode(img_thresh_high,kernel,iterations=1)

cv2.imwrite('../trec_images/longan_2/longan_2_thresh_morph.jpg',img_thresh_high)

img_cntr, contours, hierarchy = cv2.findContours(img,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
img = cv2.drawContours(img_cntr, contours, -1, (255,255,0), 3)
cv2.imwrite('../trec_images/longan_2/longan_2_contour.jpg',img)

##################

# img = cv2.erode(img,kernel,iterations = 3)
# img = cv2.dilate(img,kernel,iterations = 1)

# img = cv2.erode(img,kernel,iterations = 3)
# img = cv2.dilate(img,kernel,iterations = 1)

# img = cv2.GaussianBlur(img,(3,3),0)
# ret, img = cv2.threshold(img,0,255,0)

# img = cv2.GaussianBlur(img,(3,3),0)
# ret, img = cv2.threshold(img,0,255,0)
# img = cv2.erode(img,kernel,iterations = 1)

##################

# img = cv2.erode(img,kernel,iterations = 3)
# img = cv2.dilate(img,kernel,iterations = 3)

##################

# img = cv2.GaussianBlur(img,(3,3),0)
# ret, img = cv2.threshold(img,0,255,0)

# img = cv2.GaussianBlur(img,(3,3),0)
# ret, img = cv2.threshold(img,50,255,0)
# img = cv2.erode(img,kernel,iterations = 1)

# img = cv2.GaussianBlur(img,(3,3),0)
# ret, img = cv2.threshold(img,50,255,0)

# img = cv2.GaussianBlur(img,(3,3),0)
# ret, img = cv2.threshold(img,50,255,0)
# img = cv2.erode(img,kernel,iterations = 1)

##################

# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 1)

# img = cv2.GaussianBlur(img,(9,9),0)
# cv2.imwrite('../trec_images/longan_2/longan_2_gaussian_01.jpg',img)

# img = cv2.erode(img,kernel,iterations = 5)
# img = cv2.dilate(img,kernel,iterations = 5)
# cv2.imwrite('../trec_images/longan_2/longan_2_open_morph_thresh.jpg',img)

# ret, img = cv2.threshold(img,50,255,0)
# img_cntr, contours, hierarchy = cv2.findContours(img,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
# img = cv2.drawContours(img_cntr, contours, -1, (255,255,0), 3)
# cv2.imwrite('../trec_images/longan_2/longan_2_contour.jpg',img)
