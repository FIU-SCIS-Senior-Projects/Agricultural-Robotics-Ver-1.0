import cv2
import numpy as np

img = cv2.imread('../trec_images/coconut_2/coconut_2_720x477.jpg')

f_img = img.astype(float)

f_img_numer = np.square(f_img[:,:,2] + f_img[:,:,1])
print(f_img_numer)
f_img_denom = np.square(f_img[:,:,2] - f_img[:,:,1])
print(f_img_denom)
zeros = f_img_denom < 0.000001
print(zeros)
f_img_denom[zeros] = 1.0

f_img = np.sqrt(f_img_numer / f_img_denom) - 127
print(f_img)
zeros = f_img < 0.000001
print(zeros)
f_img[zeros] = 1.0
print(f_img)
cv2.imwrite('../trec_images/coconut_2/coconut_2_ratio.jpg',f_img)

green_less_than_blue_indices = img[:,:,1] <= img[:,:,0]
img[green_less_than_blue_indices] = 0

red_less_than_green_indices = img[:,:,2] <= img[:,:,1]
img[red_less_than_green_indices] = 0

cv2.imwrite('../trec_images/coconut_2/coconut_2_not_brown_subtraction.jpg',img)

img = cv2.Laplacian(img,cv2.CV_8U)
cv2.imwrite('../trec_images/coconut_2/coconut_2_laplacian.jpg',img)
