import cv2
import numpy as np

img = cv2.imread('../trec_images/longan_training_sets/longan_training_source_pos_quadrupled.jpg')

img = cv2.bilateralFilter(img,13,75,75)

cv2.imwrite('../trec_images/longan_training_sets/longan_training_source_pos_quadrupled_bilateral.jpg',img)