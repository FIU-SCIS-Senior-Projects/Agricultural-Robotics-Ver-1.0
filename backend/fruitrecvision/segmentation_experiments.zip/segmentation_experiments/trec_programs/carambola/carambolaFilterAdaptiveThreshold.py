import cv2 as cv
import numpy as np

img = cv.imread('tree_carambola_400x315.jpg')
img = cv.medianBlur(img,5)
cv.imwrite('tree_carambola_400x315_median_blur.jpg',img)
th3 = cv.adaptiveThreshold(img,255,cv.ADAPTIVE_THRESH_GAUSSIAN_C,\
  cv.THRESH_BINARY,11,2)

cv.imwrite('tree_carambola_400x315_adpt_thresh.jpg',th3)