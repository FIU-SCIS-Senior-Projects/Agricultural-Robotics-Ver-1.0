import cv2 as cv
import numpy as np

img = cv.imread('tree_carambola_400x315.jpg')
b, g, r = cv.split(img)
# cv.imwrite('tree_carambola_400x315_r.jpg',r)
print (r)
# cv.imwrite('tree_carambola_400x315_g.jpg',g)
# print (g)
# cv.imwrite('tree_carambola_400x315_b.jpg',b)
# print (b)
r_thresh = r.copy()
r_thresh_indices = r_thresh < 150
r_thresh[r_thresh_indices] = 0

mrg = cv.merge((b*0,g*0,r_thresh))
# print (mrg)
cv.imwrite('tree_carambola_400x315_red_t150.jpg',mrg)