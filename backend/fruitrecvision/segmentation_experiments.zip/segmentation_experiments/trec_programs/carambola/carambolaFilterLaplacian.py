import cv2
import numpy as np

img = cv2.imread('tree_carambola_736x552.jpg')
# img = cv2.Laplacian(img,cv2.CV_32F)

# img = cv2.bilateralFilter(img,3,35,35)
# img = cv2.bilateralFilter(img,5,35,35)
# img = cv2.bilateralFilter(img,7,35,35)
# img = cv2.bilateralFilter(img,9,35,35)
# img = cv2.bilateralFilter(img,11,35,35)
# img = cv2.bilateralFilter(img,13,35,35)
# img = cv2.bilateralFilter(img,15,35,35)
# img = cv2.bilateralFilter(img,17,35,35)
# img = cv2.bilateralFilter(img,19,35,35)

######

img = cv2.bilateralFilter(img,25,35,35)
img = cv2.bilateralFilter(img,23,35,35)
img = cv2.bilateralFilter(img,21,35,35)
img = cv2.bilateralFilter(img,19,35,35)
img = cv2.bilateralFilter(img,17,35,35)
img = cv2.bilateralFilter(img,15,35,35)
img = cv2.bilateralFilter(img,13,35,35)
img = cv2.bilateralFilter(img,11,35,35)
img = cv2.bilateralFilter(img,9,35,35)
img = cv2.bilateralFilter(img,7,35,35)
img = cv2.bilateralFilter(img,5,35,35)
img = cv2.bilateralFilter(img,3,35,35)

cv2.imwrite('tree_carambola_736x552_rbg_bilat_1.jpg',img)

# img = cv2.adaptiveBilateralFilter(img,15,35)
# img = cv2.adaptiveBilateralFilter(img,13,35)
# img = cv2.adaptiveBilateralFilter(img,11,35)
# img = cv2.adaptiveBilateralFilter(img,9,35)
# img = cv2.adaptiveBilateralFilter(img,7,35)
# img = cv2.adaptiveBilateralFilter(img,5,35)
# img = cv2.adaptiveBilateralFilter(img,3,35)

# img = cv2.bilateralFilter(img,15,25,25)
# img = cv2.bilateralFilter(img,13,25,25)
# img = cv2.bilateralFilter(img,11,25,25)
# img = cv2.bilateralFilter(img,9,25,25)
# img = cv2.bilateralFilter(img,7,25,25)
# img = cv2.bilateralFilter(img,5,25,25)
# img = cv2.bilateralFilter(img,3,25,25)

# img = cv2.bilateralFilter(img,9,35,35)
# img = cv2.bilateralFilter(img,9,35,35)
# img = cv2.bilateralFilter(img,9,35,35)
# img = cv2.bilateralFilter(img,9,35,35)
# img = cv2.bilateralFilter(img,9,35,35)
# img = cv2.bilateralFilter(img,9,35,35)
# img = cv2.bilateralFilter(img,9,35,35)

# img = cv2.bilateralFilter(img,7,35,35)
# img = cv2.bilateralFilter(img,7,35,35)
# img = cv2.bilateralFilter(img,7,35,35)
# img = cv2.bilateralFilter(img,7,35,35)
# img = cv2.bilateralFilter(img,7,35,35)
# img = cv2.bilateralFilter(img,7,35,35)

# img = cv2.Sobel(img,cv2.CV_32F,1,0,ksize=7)
# img = cv2.Sobel(img,cv2.CV_32F,0,1,ksize=5)
# img = cv2.Laplacian(img,cv2.CV_32F)
# img = cv2.Laplacian(img,cv2.CV_32F)
# img = cv2.bilateralFilter(img,7,35,35)


# laplacian = cv2.Sobel(img,cv2.CV_32F,0,1,ksize=5)

# green_major_indices = (img[:,:,2] - img[:,:,1]) / (img[:,:,2] + img[:,:,1]) < 0.25
green_major_indices = img[:,:,2] < img[:,:,1]
img[green_major_indices] = 0
cv2.imwrite('tree_carambola_736x552_rbg_green_sub_1.jpg',img)
blue_major_indices = (img[:,:,2] - img[:,:,0]) / (img[:,:,2] + img[:,:,0]) < 0.5
# blue_major_indices = img[:,:,2] < img[:,:,0]*1.5
img[blue_major_indices] = 0
cv2.imwrite('tree_carambola_736x552_rbg_blue_sub_1.jpg',img)

# green_threshold_indices = img[:,:,1] < img[:,:,0]*1.25
# img[green_threshold_indices] = 0

# blue_threshold_indices = img[:,:,0]*3 > 
# img[blue_threshold_indices] = 0

# green_major_indices = img[:,:,2] / img[:,:,0] < 1.5
# img[green_major_indices] = 0

# b, g, r = cv2.split(img)

# b_thresh_indices = b > 30 
# b[blue_thresh_indices] = 0

# blue_thresh_img = cv2.merge((b,g,r))

# white_major_indices = img[:,:,:] > np.array([225,225,225])
# img[white_major_indices] = 255

# print (img_indices)

img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
low_sat_indices = img[:,:,1] < 70
img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
img[low_sat_indices] = 0

cv2.imwrite('tree_carambola_736x552_hsv_low_sat_sub_1.jpg',img)

kernel = np.ones((3,3),np.uint8)

# img = cv2.dilate(img,kernel,iterations = 3)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 3)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 3)
# img = cv2.erode(img,kernel,iterations = 1)

img = cv2.dilate(img,kernel,iterations = 2)
img = cv2.erode(img,kernel,iterations = 1)
img = cv2.dilate(img,kernel,iterations = 2)
img = cv2.erode(img,kernel,iterations = 1)
img = cv2.dilate(img,kernel,iterations = 2)
img = cv2.erode(img,kernel,iterations = 1)
img = cv2.dilate(img,kernel,iterations = 2)
img = cv2.erode(img,kernel,iterations = 1)

cv2.imwrite('tree_carambola_736x552_rgb_dilate-erode_1.jpg',img)

# img = cv2.bilateralFilter(img,21,35,35)
# img = cv2.bilateralFilter(img,19,35,35)
# img = cv2.bilateralFilter(img,17,35,35)
# img = cv2.bilateralFilter(img,15,35,35)
# img = cv2.bilateralFilter(img,13,35,35)
# img = cv2.bilateralFilter(img,11,35,35)
# img = cv2.bilateralFilter(img,9,35,35)
# img = cv2.bilateralFilter(img,7,35,35)
# img = cv2.bilateralFilter(img,5,35,35)
# img = cv2.bilateralFilter(img,3,35,35)

# cv2.imwrite('tree_carambola_736x552_rbg_bilat_2.jpg',img)

# img = cv2.dilate(img,kernel,iterations = 2)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 2)
# img = cv2.erode(img,kernel,iterations = 1)
# img = cv2.dilate(img,kernel,iterations = 2)
# img = cv2.erode(img,kernel,iterations = 1)

# cv2.imwrite('tree_carambola_736x552_rgb_dilate-erode_2.jpg',img)

# img = cv2.dilate(img,kernel,iterations = 3)
# img = cv2.erode(img,kernel,iterations = 2)
# img = cv2.dilate(img,kernel,iterations = 3)
# img = cv2.erode(img,kernel,iterations = 2)
# img = cv2.dilate(img,kernel,iterations = 3)
# img = cv2.erode(img,kernel,iterations = 2)
# img = cv2.dilate(img,kernel,iterations = 3)
# img = cv2.erode(img,kernel,iterations = 2)

# img = cv2.dilate(img,kernel,iterations = 3)

# img = cv2.Sobel(img,cv2.CV_32F,1,0,ksize=5)
# erosion = cv2.erode(img,kernel,iterations = 1)

img = cv2.Laplacian(img,cv2.CV_32F)
cv2.imwrite('tree_carambola_736x552_rgb_laplacian_1.jpg',img)
# img = cv2.dilate(img,kernel,iterations = 1)
# img = cv2.erode(img,kernel,iterations = 2)
# img = cv2.dilate(img,kernel,iterations = 1)
# img = cv2.erode(img,kernel,iterations = 2)
# img = cv2.dilate(img,kernel,iterations = 1)
# img = cv2.erode(img,kernel,iterations = 2)

img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

ret, img = cv2.threshold(img,25,255,cv2.THRESH_BINARY)

cv2.imwrite('tree_carambola_736x552_rgb_laplacian_2.jpg',img)

# kernel = np.ones((30,30),np.uint8)

# img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)
# img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)

cv2.imwrite('tree_carambola_736x552_sobelx11_hsv.jpg',img)

# img = cv2.pyrDown(img)
# cv2.imwrite('tree_carambola_400x315_pyrDown.jpg',img)
