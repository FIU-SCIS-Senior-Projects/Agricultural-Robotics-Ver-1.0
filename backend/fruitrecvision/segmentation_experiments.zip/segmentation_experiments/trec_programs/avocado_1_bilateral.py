import cv2
import numpy as np

img = cv2.imread('../trec_images/avocado_1/avocado_1.jpg')

kernel = np.ones((3,3),np.uint8)

img_dilate = cv2.dilate(img,kernel,iterations=1)
img_erode = cv2.erode(img,kernel,iterations=1)

img_gradient = img_dilate - img_erode

cv2.imwrite('../trec_images/avocado_1/avocado_1_raw_gradient.jpg',img_gradient)

img_bi = cv2.bilateralFilter(img,33,50,50)

cv2.imwrite('../trec_images/avocado_1/avocado_1_bi.jpg',img_bi)

img_dilate = cv2.dilate(img_bi,kernel,iterations=1)
img_erode = cv2.erode(img_bi,kernel,iterations=1)

img_gradient = img_dilate - img_erode

cv2.imwrite('../trec_images/avocado_1/avocado_1_bi_gradient.jpg',img_gradient)

img_lap = cv2.Laplacian(img,cv2.CV_32F)

cv2.imwrite('../trec_images/avocado_1/avocado_1_lap.jpg',img_lap)

# img_gradient = cv2.bilateralFilter(img_gradient,3,50,50)
# img_gradient = cv2.bilateralFilter(img_gradient,3,50,50)

# img_gradient = cv2.morphologyEx(img_gradient, cv2.MORPH_CLOSE, kernel)
# cv2.imwrite('../trec_images/coconut_1/coconut_1_close.jpg',img_gradient)