import cv2
import numpy as np

img = cv2.imread('../trec_images/avocado_1280x720.jpg')
img = cv2.bilateralFilter(img,11,75,25)
cv2.imwrite('../trec_images/avocado_1280x720_bilateral.jpg',img)