import cv2
import numpy as np

img = cv2.imread('../trec_images/coconut_1/coconut_1_720x477.jpg')

kernel = np.ones((3,3),np.uint8)

img_dilate = cv2.dilate(img,kernel,iterations=1)
img_erode = cv2.erode(img,kernel,iterations=1)

img_gradient = img_dilate - img_erode

print(img_gradient)
# img_gradient = cv2.bilateralFilter(img_gradient,3,50,50)
# img_gradient = cv2.bilateralFilter(img_gradient,3,50,50)
# img_gradient = cv2.bilateralFilter(img_gradient,3,50,50)

# img_gradient = cv2.morphologyEx(img_gradient, cv2.MORPH_CLOSE, kernel)
# cv2.imwrite('../trec_images/coconut_1/coconut_1_close.jpg',img_gradient)

cv2.imwrite('../trec_images/coconut_1/coconut_1_gradient.jpg',img_gradient)

img_gray = cv2.cvtColor(img_gradient,cv2.COLOR_BGR2GRAY)
cv2.imwrite('../trec_images/coconut_1/coconut_1_gray.jpg',img_gray)

kernel = np.ones((5,5),np.uint8)

img_gray = cv2.morphologyEx(img_gray, cv2.MORPH_CLOSE, kernel)
cv2.imwrite('../trec_images/coconut_1/coconut_1_gray_open.jpg',img_gray)

# img_gray = cv2.GaussianBlur(img_gray,(7,7),0)
# cv2.imwrite('../trec_images/coconut_1/coconut_1_gray_gaussian_01.jpg',img_gray)

img_gray = cv2.bilateralFilter(img_gray,3,50,50)
img_gray = cv2.bilateralFilter(img_gray,3,50,50)
img_gray = cv2.bilateralFilter(img_gray,3,50,50)

cv2.imwrite('../trec_images/coconut_1/coconut_1_gray_bilateral_01.jpg',img_gray)

img_gray = 2 * img_gray
ret, img_gray = cv2.threshold(img_gray,128,255,0)
cv2.imwrite('../trec_images/coconut_1/coconut_1_thresh.jpg',img_gray)

img_cntr, contours, hierarchy = cv2.findContours(img_gray,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
img_contour = cv2.drawContours(img_cntr, contours, -1, (255,255,0), 3)
cv2.imwrite('../trec_images/coconut_1/coconut_1_gradient_contour.jpg',img_contour)

# img = cv2.GaussianBlur(img,(3,3),0)
# img = cv2.GaussianBlur(img,(3,3),0)
# img = cv2.GaussianBlur(img,(3,3),0)
# cv2.imwrite('../trec_images/coconut_1/coconut_1_gaussian_01.jpg',img)

# img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)
# cv2.imwrite('../trec_images/coconut_1/coconut_1_close.jpg',img)

# img = cv2.dilate(img,kernel,iterations = 5)
# img = cv2.erode(img,kernel,iterations = 5)

kernel = np.ones((3,3),np.uint8)

img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)
cv2.imwrite('../trec_images/coconut_1/coconut_1_open.jpg',img)

img = cv2.bilateralFilter(img,3,50,50)
img = cv2.bilateralFilter(img,3,50,50)
img = cv2.bilateralFilter(img,3,50,50)

cv2.imwrite('../trec_images/coconut_1/coconut_1_bilateral_01.jpg',img)

# img = cv2.dilate(img,kernel,iterations = 5)
# img = cv2.erode(img,kernel,iterations = 5)

img = cv2.pyrMeanShiftFiltering(img,8,40)
cv2.imwrite('../trec_images/coconut_1/coconut_1_meanshift_01.jpg',img)

h, w = img.shape[:2]
mask = np.zeros((h+2, w+2), np.uint8)

cv2.floodFill(img, mask, (400,100), (0,0,0), (3,3,3), (3,3,3))
cv2.floodFill(img, mask, (20,20), (0,0,0), (9,9,9), (9,9,9))

print(img)
cv2.imwrite('../trec_images/coconut_1/coconut_1_floodfill_01.jpg',img)

green_less_than_blue_indices = img[:,:,1] <= img[:,:,0]
img[green_less_than_blue_indices] = 0

red_less_than_blue_indices = img[:,:,2] <= img[:,:,0]
img[red_less_than_blue_indices] = 0

cv2.imwrite('../trec_images/coconut_1/coconut_1_not_brown_subtraction.jpg',img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
low_val_indices = img[:,:,2] < 100

img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
img[low_val_indices] = 0

cv2.imwrite('../trec_images/coconut_1/coconut_1_low_val_subtraction.jpg',img)

img = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
low_sat_indices = img[:,:,1] < 100

img = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
img[low_sat_indices] = 0

cv2.imwrite('../trec_images/coconut_1/coconut_1_low_sat_subtraction.jpg',img)

# img_gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

# img = cv2.GaussianBlur(img,(3,3),0)
# ret, img = cv2.threshold(img,0,255,0)

img = cv2.erode(img,kernel,iterations=1)

img = cv2.bilateralFilter(img,3,50,50)
img = cv2.bilateralFilter(img,3,50,50)
img = cv2.bilateralFilter(img,3,50,50)

cv2.imwrite('../trec_images/coconut_1/coconut_1_bilateral_02.jpg',img)

img_dilate = cv2.dilate(img,kernel,iterations=1)
img_erode = cv2.erode(img,kernel,iterations=1)

img_gradient = img_dilate - img_erode

print(img_gradient)
# img_gradient = cv2.bilateralFilter(img_gradient,3,50,50)
# img_gradient = cv2.bilateralFilter(img_gradient,3,50,50)
# img_gradient = cv2.bilateralFilter(img_gradient,3,50,50)

# img_gradient = cv2.morphologyEx(img_gradient, cv2.MORPH_CLOSE, kernel)
# cv2.imwrite('../trec_images/coconut_1/coconut_1_close.jpg',img_gradient)

cv2.imwrite('../trec_images/coconut_1/coconut_1_gradient_2.jpg',img_gradient)
####

# Threshold.
# Set values equal to or above 220 to 0.
# Set values below 220 to 255.
 
# th, im_th = cv2.threshold(im_in, 220, 255, cv2.THRESH_BINARY_INV);
 
# Copy the thresholded image.
# im_floodfill = im_th.copy()
 
# Mask used to flood filling.
# Notice the size needs to be 2 pixels than the image.
# h, w = im_th.shape[:2]
# mask = np.zeros((h+2, w+2), np.uint8)
 
# Floodfill from point (0, 0)
# cv2.floodFill(im_floodfill, mask, (0,0), 255);
 
# Invert floodfilled image
# im_floodfill_inv = cv2.bitwise_not(im_floodfill)
 
# Combine the two images to get the foreground.
# im_out = im_th | im_floodfill_inv
 
# Display images.
# cv2.imshow("Thresholded Image", im_th)
# cv2.imshow("Floodfilled Image", im_floodfill)
# cv2.imshow("Inverted Floodfilled Image", im_floodfill_inv)
# cv2.imshow("Foreground", im_out)
# cv2.waitKey(0)
